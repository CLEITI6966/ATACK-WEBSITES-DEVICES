const axios = require('axios');
const readline = require('readline');

// Criação da interface para capturar o URL/IP do usuário
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Detecta quando o usuário pressiona Ctrl+D
rl.on('close', () => {
  console.log('\nProcesso encerrado pelo usuário.');
  process.exit(0);
});

// Pergunta o URL ou IP do site
rl.question('Digite a URL ou IP do site: ', (url) => {
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    console.log('Por favor, insira um URL válido começando com http:// ou https://');
    rl.close();
    return;
  }

  console.log('Iniciando requisições rápidas. Pressione Ctrl+C para interromper.');

  // Função de delay para controlar a frequência das requisições
  const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // Função para realizar requisições em loop sequencial
  const realizarRequisicoes = async () => {
    let i = 0;
    while (true) {
      try {
        // Faz uma requisição
        const response = await axios.get(url);
        console.log(`Requisição ${i + 1} realizada com sucesso: ${response.status}`);
        
        // Atraso de 0.1 segundo entre as requisições
        await delay(000000000000000000000000);  // 100ms (0.1s)

        i++;
      } catch (error) {
        if (error.response && error.response.status === 429) {
          console.log('Limite de requisições atingido. Aguardando...');
          await delay(00000);  // Espera 10 segundos antes de tentar novamente
        } else {
          console.error(`Erro na requisição: ${error.message}`);
        }
      }
    }
  };

  // Inicia o loop de requisições
  realizarRequisicoes();
});
